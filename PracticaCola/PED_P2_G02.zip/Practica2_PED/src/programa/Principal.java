/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package programa;

import librerias.utilidades.Menus;
import java.util.ArrayList;
import librerias.estructurasDeDatos.lineales.LECola;
import librerias.tiposDeDatos.Trabajo;
import static programa.OpcionesMenuPrincipal.*;

/**
 *Clase principal. El metodo que arranca el programa se encuentra en esta clase
 * @author Adrian Herrero Artola y Juan Blanco Martin
 */
public class Principal {
    private static final int TAM_IMPRESORA = 9;
    /**Metodo principal que inicia la ejecucion del programa
     * @param args the command line arguments
     */
    public static void main(String[] args){
        menuPrincipal();
    }
    
        
    /**Metodo que invoca los metodos utilizados en cada opcion del menu principal, en funcion de la opcion que introduzca el usuario por teclado
     */
    public static void menuPrincipal(){
        int opc = -1;
        
        ArrayList<LECola<Trabajo>> impresora = new ArrayList();
        
        iniciarImpresora(impresora); // Introducimos las 9 colas en la impresora
        
        do {
            opc = Menus.menuPrincipal(opc);

            switch(opc){
                case 0:{ System.out.println("\n\n\n*** Gracias por utilizar la aplicación PrintManagement ***\n\n\n"); } break;
                
                case 1:{//Enviar un trabajo a la impresora
                    enviarTrabajo(impresora);
                } break;

                case 2:{//Imprimir trabajos
                    imprimirTrabajos(impresora);
                } break;

                case 3:{//Mostrar trabajo mas pesado
                    trabajoMasPesado(impresora);
                } break;
                        
                case 4:{//Mostrar tiempo de espera de un usuario
                    informarEspera(impresora);
                } break;
                    
                case 5:{//Informe de trabajos por prioridad
                    informeTodasPrioridades(impresora);
                } break;
                    
                case 6:{//Informe de trabajos de una prioridad
                    informeUnaPrioridad(impresora);
                } break;
                    
                case 7:{//Reducir espera en una prioridad
                    reducirEspera(impresora);
                } break;
                    
                case 8:{//Reiniciar el Sistema de impresion
                    reiniciarSistema(impresora);
                } break;
                
                default:{ System.out.println("Error: Introduce un numero que corresponda a alguna de las posibles opciones del Menu Principal\n"); }
            }
        }while(opc !=0);
    }
    
    /**Metodo que incluye las 9 colas de trabajos en la impresora
     * @param impresora Es el ArrayList de colas de trabajos
     */
    public static void iniciarImpresora(ArrayList<LECola<Trabajo>> impresora){
        for(int i = 0; i < TAM_IMPRESORA; i++) impresora.add(i, new LECola());
    }
}
