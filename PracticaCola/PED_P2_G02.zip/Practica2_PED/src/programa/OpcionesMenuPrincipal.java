/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package programa;

import librerias.utilidades.Formatos;
import static librerias.utilidades.Menus.introducirIdUsuario;
import static librerias.utilidades.Menus.introducirPesoTrabajo;
import static librerias.utilidades.Menus.introducirPrioridad;
import static librerias.utilidades.Menus.introducirTituloTrabajo;
import java.util.ArrayList;
import librerias.estructurasDeDatos.lineales.LECola;
import librerias.estructurasDeDatos.lineales.NodoLEG;
import librerias.tiposDeDatos.Trabajo;

/** Clase que engloba los metodos con los que se ejecutaran las acciones de las diferentes opciones del menu principal
 *
 * @author Adrian Herrero Artola y Juan Blanco Martin
 */
public class OpcionesMenuPrincipal {
    
    /** Constructor de la clase que no recibe ni inicializa ningun parametro, sino que llama al constructor de la superclase
     * 
     */
    public OpcionesMenuPrincipal(){
        super();
    }
    
    /** Metodo que solicita al usuario la introduccion por teclado de un ID de usuario (valor entero entre 100-999), el titulo y el peso del trabajo a imprimir, y envia un trabajo con los datos introducidos a la impresora
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void enviarTrabajo(ArrayList<LECola<Trabajo>> impresora){
        //Introduccion de datos del usuario
        int id = introducirIdUsuario();
        String titulo = introducirTituloTrabajo();  System.out.println();
        long peso = introducirPesoTrabajo();        System.out.println();
        
        Trabajo nuevo = new Trabajo(id, titulo, peso);
        
        //Calculo de prioridad
        int prioridad = nuevo.obtenerPrioridad(); //Obtienes un entero del 1 al 9
                
        LECola<Trabajo> aux = impresora.get((prioridad-1));
        
        aux.encolar(nuevo);
        
        //el arrayList tiene 9 posiciones (0-8)
        impresora.set((prioridad-1), aux);
        
        System.out.println("Informacion:  El trabajo se ha enviado correctamente a la impresora.\n\n");
    }
    
    /** Metodo utilizado para imprimir trabajos
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void imprimirTrabajos(ArrayList<LECola<Trabajo>> impresora){
        if(!esVacia(impresora)){
            boolean seguirImprimiendo;
            Trabajo impreso;
            
            int cola = buscarColaPrioritaria(impresora);//Busca la siguiente cola que contenga trabajos para ser impresos
                        
            do{
                impreso = impresora.get(cola).desencolar();
                
                System.out.println("Se ha impreso el trabajo '"+impreso.getTitulo()+"' (Usuario "+impreso.getID_Usuario()+", Prioridad "+impreso.obtenerPrioridad()+")\n");

                if(!esVacia(impresora)){//Al menos existe 1 cola que contiene, al menos, 1 trabajo para ser impreso
                    System.out.print("Desea imprimir otro trabajo? (S/N): ");
                    seguirImprimiendo = Formatos.continuarProcedimiento();   System.out.println();
                    
                    if(seguirImprimiendo){//Buscamos el siguiente trabajo a ser impreso
                        if(impresora.get(cola).esVacia()){//Pasamos a la siguiente cola que contenga trabajos a imprimir
                            cola = buscarColaPrioritaria(impresora);
                        }                        
                    }
                }
                else{
                    seguirImprimiendo = false;
                    System.out.println("\nNo quedan mas trabajos a la espera de impresion.\n\n");
                }
            }while(seguirImprimiendo);
        }
        else{ System.out.println("\nERROR: No hay trabajos a la espera de impresion.\n       El Sistema se encuentra en estado inicial.\n\n"); }
    }
    
    /** Metodo que muestra en pantalla un mensaje indicando cual es el trabajo que tiene mayor tamano (en kilobytes) que se encuentra a la espera de ser impreso
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void trabajoMasPesado(ArrayList<LECola<Trabajo>> impresora){
        if(!esVacia(impresora)){ 
            Trabajo masPesado = new Trabajo(1000, "Predeterminado", 0); // Fuerzo a que el trabajo predeterminado tenga una prioridad de 10 (al dividir entre 100 con el metodo obtenerPrioridad) la cual es menor que cualquier prioridad a la que se vaya a comparar, y tambien le fuerzo a que tenga un peso 0, mayor que cualquier peso con el que se vaya a comparar. (Este trabajo nunca se mostrara puesto que la lista no esta vacia)
            System.out.println("\n\t\t\t\tTRABAJO DE IMPRESION MAS PESADO\n");
            System.out.println("ID_Usuario\tNivel de Prioridad\tTitulo\t\t\t\t\t\tTamano (Kb)");
            System.out.println("____________________________________________________________________________________________________");
            for(int cola = 0; cola < impresora.size(); cola++){
                for(NodoLEG<Trabajo> aux = impresora.get(cola).getPrimero(); aux != null; aux = aux.getSiguiente()){
                    if(masPesado.getPeso() < aux.getDato().getPeso()){
                        masPesado = new Trabajo(aux.getDato().getID_Usuario(), aux.getDato().getTitulo(), aux.getDato().getPeso());
                    }
                    else if((masPesado.getPeso() == aux.getDato().getPeso()) && (masPesado.obtenerPrioridad() > aux.getDato().obtenerPrioridad())){
                        masPesado = new Trabajo(aux.getDato().getID_Usuario(), aux.getDato().getTitulo(), aux.getDato().getPeso());
                    }
                    else if((masPesado.getPeso() == aux.getDato().getPeso()) && (masPesado.obtenerPrioridad() == aux.getDato().obtenerPrioridad())){
                        masPesado = new Trabajo(aux.getDato().getID_Usuario(), aux.getDato().getTitulo(), aux.getDato().getPeso());
                    }
                }
            }
            mostrarMasPesado(masPesado);
        }
        else{ System.out.println("\nERROR: No hay trabajos a la espera de impresion.\n       El Sistema se encuentra en estado inicial.\n\n"); }
    }
    
    /** Metodo que solicita un ID_Usuario y muestra en pantalla cuantos trabajos seran impresos ANTES de que se imprima el primer trabajo que envio este usuario, incluyendo los trabajos que tienen una prioridad mayor
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void informarEspera(ArrayList<LECola<Trabajo>> impresora){
        if(!esVacia(impresora)){
            boolean encontrado = false;
            int cola = 0;
            int trabajosDelante = 0;
            NodoLEG<Trabajo> aux;
            int id = introducirIdUsuario();
            
            while((!encontrado) && (cola < impresora.size())){
                if(!impresora.get(cola).esVacia()){
                    aux = impresora.get(cola).getPrimero();
                    while((!encontrado) && (aux != null)){
                        if(id == aux.getDato().getID_Usuario()){ encontrado = true; }
                        else{ trabajosDelante++; }
                        aux = aux.getSiguiente();
                    }
                }
                if(!encontrado){ cola++; }
            }
            
            if(encontrado){
                if(0 < trabajosDelante){
                    System.out.print("**El usuario "+id+" tiene delante "+trabajosDelante+" trabajo");
                    if(trabajosDelante == 1){ System.out.println(".\n\n"); }
                    else{ System.out.println("s.\n\n"); }                        
                }
                else{ System.out.println("**El usuario "+id+" no tiene trabajos delante.\n  Su primer trabajo es el prioritario para ser impreso.\n\n"); }
            }
            else{ System.out.println("**No existen trabajos pendientes del usuario "+id+".\n\n"); }
        }
        else{ System.out.println("\nERROR: No hay trabajos a la espera de impresion.\n       El Sistema se encuentra en estado inicial.\n\n"); }
    }
    
    /** Metodo que muestra en pantalla un listado indicando cuantos trabajos se encuentran a la espera de impresion en cada una de las distintas prioridades existentes
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void informeTodasPrioridades(ArrayList<LECola<Trabajo>> impresora){        
        if(!esVacia(impresora)){
            int totalPendientes = 0;
            int totalCola;
            System.out.println("\n\tINFORME DE TRABAJOS POR PRIORIDAD\n");
            System.out.println("Nivel de Prioridad\t\tTrabajos en espera");
            System.out.println("___________________________________________________");
            for(int cola = 0; cola < impresora.size(); cola++){
                totalCola = impresora.get(cola).contarElemCola(impresora.get(cola).getPrimero());
                System.out.println("        "+(cola+1)+"\t\t\t\t"+totalCola);                    
                totalPendientes += totalCola;
            }
            System.out.println("---------------------------------------------------");
            System.out.println("   Numero total de trabajos pendientes: "+ totalPendientes);
            System.out.println("---------------------------------------------------");
            System.out.println("\n");
        }
        else{ System.out.println("\nERROR: No hay trabajos a la espera de impresion.\n       El Sistema se encuentra en estado inicial.\n\n"); }
    }
    
    /** Metodo que solicita al usuario una prioridad (1..9) y muestra en pantalla un listado indicando los trabajos con esa prioridad que se encuentran a la espera de impresion
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void informeUnaPrioridad(ArrayList<LECola<Trabajo>> impresora){
        int prioridad = introducirPrioridad();
        
        if(!impresora.get(prioridad-1).esVacia()){            
            System.out.println("\n\tINFORME DE TRABAJOS con Prioridad "+prioridad+"\n");
            System.out.println("ID Usuario\t\tTitulo");
            System.out.println("______________________________________________________________");
            for(NodoLEG<Trabajo> aux = impresora.get(prioridad-1).getPrimero(); aux != null; aux = aux.getSiguiente()){
                    System.out.println("   "+aux.getDato().getID_Usuario()+"\t\t\t"+aux.getDato().getTitulo());
            }
            System.out.println("\n");
        }
        else{ System.out.println("\nERROR: No hay trabajos con esa prioridad a la espera de impresion.\n\n"); }
    }
    
    /** Metodo que solicita una prioridad (1..9) y elimina algunos de los trabajos que actualmente se encuentran en espera con esa prioridad, mostrando un mensaje en que indica que trabajo se ha eliminado de la cola, con cada trabajo eliminado de la misma
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void reducirEspera(ArrayList<LECola<Trabajo>> impresora){
        int prioridad = introducirPrioridad();
        
        if(!impresora.get(prioridad-1).esVacia()){
            int distancia = 2;
            int cont = 1;
            int numElems = impresora.get(prioridad-1).contarElemCola(impresora.get(prioridad-1).getPrimero());
            
            Trabajo t;
            LECola<Trabajo> colaAux; // Creamos una cola auxiliar

            if(numElems == 1){
                System.out.println("No se ha reducido la espera en la prioridad "+prioridad+", ya que solo hay 1 trabajo en esta cola.");
            }
            
            else{
                while(numElems >= distancia){
                    colaAux = new LECola();
                    for(int i = 0; i < numElems; i++){
                        // Desencolamos un trabajo
                        t = impresora.get(prioridad-1).desencolar();

                        if((cont%distancia) == 1){ // Si el trabajo es victima, se imprime
                            System.out.println("Se ha eliminado el trabajo <"+t.getID_Usuario()+"><"+t.getTitulo()+"><"+t.getPeso()+"> de la cola");
                        }

                        else{ // En caso contrario, se encola en la cola auxiliar
                            colaAux.encolar(t);
                        }

                        cont++;
                    }
                    cont = 1;
                    distancia++;
                    impresora.set(prioridad-1, colaAux); // Reemplazamos el puntero al primero de la cola vigente (en este momento vacia), por el puntero al primer elemento de la cola auxiliar, que es la que contiene los trabajos que no han sido impresos
                    numElems = impresora.get(prioridad-1).contarElemCola(impresora.get(prioridad-1).getPrimero()); // Calculamos el numero de elementos de la cola, ahora actualizada
                }
            }            
        }
        
        else{ System.out.println("\nERROR: No hay trabajos con esa prioridad a la espera de impresion.\n"); }
        
        System.out.println("\n");
    }
    
    /** Metodo utilizado para reiniciar la impresora. Las ordenes de impresion de todos los trabajos que se encuentran a la espera de ser impresos se perderan, pero antes, el sistema de gestion de impresion muestra un mensaje en pantalla indicando que usuarios/trabajos estan afectados
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     */
    public static void reiniciarSistema(ArrayList<LECola<Trabajo>> impresora){
        if(!esVacia(impresora)){            
            System.out.println("\n\tLISTADO DE TRABAJOS DE IMPRESION ABORTADOS\n");
            System.out.println("ID Usuario\t\tTitulo");
            System.out.println("______________________________________________________________");
            for(int cola = 0; cola < impresora.size(); cola++){
                for(NodoLEG<Trabajo> aux = impresora.get(cola).getPrimero(); aux != null; aux = aux.getSiguiente()){
                    aux.setDato(impresora.get(cola).desencolar());
                    System.out.println("   "+aux.getDato().getID_Usuario()+"\t\t\t"+aux.getDato().getTitulo());
                }
            }
            System.out.println("\n");
        }
        else{ System.out.println("\nERROR: No hay trabajos a la espera de impresion.\n       El Sistema se encuentra en estado inicial.\n\n"); }
    }
    
    /** Metodo utilizado para verificar si las 9 colas que forman la impresora estan todas vacias, o no
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     * @return Si el numero de colas vacias coincide con el tamano de la impresora (9, ya que son 9 colas). En caso de coincidir, significa que la impresora esta vacia (sus 9 colas estan vacias) y devolvera true. Devolvera false en caso contrario
     */
    public static boolean esVacia(ArrayList<LECola<Trabajo>> impresora){
        int numColasVacias = 0;
        for(int i = 0; i < impresora.size(); i++){
            if(impresora.get(i).esVacia()){ numColasVacias++; }
        }
        
        return numColasVacias == impresora.size();
    }
    
    /** Metodo que busca la cola con mayor prioridad de la impresora que cuente con trabajos a la espera de impresion
     * 
     * @param impresora Es el ArrayList de 9 colas de trabajos
     * @return El indice de la cola con mayor prioridad de la impresora que cuente con trabajos a la espera de impresion
     */
    public static int buscarColaPrioritaria(ArrayList<LECola<Trabajo>> impresora){
        int prioritaria = 0;
        
        if(!esVacia(impresora)){ while(impresora.get(prioritaria).esVacia()){ prioritaria++; } } //Hallamos la primera cola que tenga trabajos para imprimir
        
        return prioritaria;
    }
    
    /** Metodo utilizado para mostrar por pantalla correctamente indexado el trabajo mas pesado a la espera de ser impreso
     * 
     * @param trabajo Es el trabajo del cual se mosrtaran sus datos por pantalla
     */
    public static void mostrarMasPesado(Trabajo trabajo){
        if(trabajo.getTitulo().length() < 8){ System.out.println("   "+trabajo.getID_Usuario()+"\t\t\t"+trabajo.obtenerPrioridad()+"\t\t"+trabajo.getTitulo()+"\t\t\t\t\t\t"+trabajo.getPeso()+"\n\n"); }
        else if(trabajo.getTitulo().length() < 16){ System.out.println("   "+trabajo.getID_Usuario()+"\t\t\t"+trabajo.obtenerPrioridad()+"\t\t"+trabajo.getTitulo()+"\t\t\t\t\t"+trabajo.getPeso()+"\n\n"); }
        else if(trabajo.getTitulo().length() < 24){ System.out.println("   "+trabajo.getID_Usuario()+"\t\t\t"+trabajo.obtenerPrioridad()+"\t\t"+trabajo.getTitulo()+"\t\t\t\t"+trabajo.getPeso()+"\n\n"); }
        else if(trabajo.getTitulo().length() < 32){ System.out.println("   "+trabajo.getID_Usuario()+"\t\t\t"+trabajo.obtenerPrioridad()+"\t\t"+trabajo.getTitulo()+"\t\t\t"+trabajo.getPeso()+"\n\n"); }
        else{ System.out.println("   "+trabajo.getID_Usuario()+"\t\t\t"+trabajo.obtenerPrioridad()+"\t\t"+trabajo.getTitulo()+"\t\t"+trabajo.getPeso()+"\n\n"); }
    }
}
