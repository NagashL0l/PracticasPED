/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package librerias.estructurasDeDatos.lineales;

/**Clase que crea los nodos LEG y contiene sus metodos
* 
* @author Adrian Herrero Artola y Juan Blanco Martin
 * @param <E> Objeto de tipo generico
 */
public class NodoLEG<E>{
    
    /**
     * Dato de tipo generico que almacena el nodo
     */
    protected E dato;

    /**
     * Puntero al siguiente nodo de la lista
     */
    protected NodoLEG<E> siguiente;
    
    /**
     *Constructor que no recibe ningun parametro y que inicializa a null tanto el dato de tipo generico que almacenara como el puntero al siguiente nodo de la lista
     */
    public NodoLEG(){
        this.dato = null;
        this.siguiente = null;
    }
    
    /** Constructor al que solo se le pasa el objeto que va a contener el nodo
     * @param dato Es el dato de tipo generico que almacenara el nodo
     */
    public NodoLEG(E dato){
        this(dato, null);
    }
    
    
    /** Constructor al que se le pasa el objeto que va a contener y el puntero siguiente
     * @param dato Es el dato de tipo generico que almacenara el nodo
     * @param siguiente Es el puntero al siguiente nodo de la lista
     */
    public NodoLEG(E dato, NodoLEG<E> siguiente){
        this.dato = dato;
        this.siguiente = siguiente;
    }

    /** Metodo que nos devuelve el objeto que almacena el nodo
     * @return dato
     */
    public E getDato() {
        return dato;
    }

    /** Metodo que actualiza el objeto que almacena el nodo
     * @param dato
     */
    public void setDato(E dato) {
        this.dato = dato;
    }

    /** Metodo que nos indica a donde apunta el puntero siguiente
     * @return siguiente
     */
    public NodoLEG getSiguiente() {
        return siguiente;
    }
    
    /** Metodo que actualiza el puntero siguiente
     * @param siguiente
     */
    public void setSiguiente(NodoLEG siguiente) {
        this.siguiente = siguiente;
    }
    
}
