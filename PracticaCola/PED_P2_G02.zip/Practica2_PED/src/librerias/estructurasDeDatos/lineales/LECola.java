/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package librerias.estructurasDeDatos.lineales;

import librerias.estructurasDeDatos.modelos.Cola;

/** Clase que se encarga de la lista de nodos LEG. Representa una Lista Enlazada Generica con Ultimo, lo cual equivale a una Cola
*
* @author Adrian Herrero Artola y Juan Blanco Martin
 * @param <E> Objeto de tipo generico
 */
public class LECola<E> implements Cola<E>{
    
    /**
     *Puntero al primer nodo de la LEG con Ultimo (es decir, de la cola)
     */
    protected NodoLEG<E> primero;

    /**
     *Puntero al ultimo nodo de la LEG con Ultimo (es decir, de la cola)
     */
    protected NodoLEG<E> ultimo; // Referencia al primer y al ultimo nodo de la lista que representa la cola
    
    /**
     *Constructor que no recibe ningun parametro y que inicializa a null tanto el puntero al primero como el puntero al ultimo de la lista
     */
    public LECola(){
        this.primero = null;
        this.ultimo = null;
    }
    
    /** Metodo que nos indica cual es el primer nodo de la lista
     * @return primero
     */
    public NodoLEG<E> getPrimero() {
        return primero;
    }

    /** Metodo que actualiza el valor del puntero primero
     * @param primero
     */
    public void setPrimero(NodoLEG<E> primero) {
        this.primero = primero;
    }

    /** Metodo que nos indica cual es el ultimo nodo de la lista
     * @return ultimo
     */
    public NodoLEG<E> getUltimo() {
        return ultimo;
    }

    /** Metodo que actualiza el valor del puntero ultimo
     * @param ultimo
     */
    public void setUltimo(NodoLEG<E> ultimo) {
        this.ultimo = ultimo;
    }
    
    /** Metodo recursivo que nos devuelve el numero de elementos que estan almacenados en la cola.
     * 
     * @param actual Es el nodo que evaluaremos en la invocacion del metodo en la que nos encontremos. Distinguimos casos en funcion de si se trata del ultimo nodo o no
     * @return 0 si el nodo actual es null, 1 + lo que resulte la llamada recursiva si el nodo actual no es null
     */
    @Override
    public int contarElemCola(NodoLEG<E> actual){
        if (actual == null) { return 0; } //Hemos llegado al siguiente elemento del que es el ultimo de la cola, es decir,al siguiente del que se encuentra en el fin de la cola
        else { return 1 + contarElemCola(actual.siguiente); }        
    }
        
    /** Metodo que permite insertar un nodo en el final de la lista (es decir, al final de la cola)
     * @param x (objeto generico)
     */
    @Override
    public void encolar(E x){
        NodoLEG<E> nuevo = new NodoLEG(x);

        if(primero != null){ ultimo.siguiente = nuevo; }
        
        else{ primero = nuevo; }        
        
        ultimo = nuevo;
    }
    
    /** Metodo que permite eliminar el primer nodo de la lista (es decir, el nodo que se encuentra al frente de la cola)
     * @return frente Es el dato que ha desencolado
     */
    @Override
    public E desencolar(){
        E frente = primero();
        
        primero = primero.siguiente;
        
        return frente;
    }
    
    /** Metodo que devuelve el dato que se encuentra en el primer nodo de la lista (es decir, el que se encuentra al frente de la cola)
     * @return retorno Es el dato contenido en el primer nodo de la cola
     */
    @Override
    public E primero(){
        E retorno;
        
        if(primero == null){ retorno = null; }
        else{ retorno = primero.dato; }
        
        return retorno;
    }
    
    /** Metodo que devuelve un booleano indicando si la cola se encuentra vacia
     * @return Si el primer dato del primer nodo de la cola es null, lo cual indicaria que la cola esta vacia y devolveria true. En caso contrario, la cola no estaria vacia y devolveria por tanto false
     */
    @Override
    public boolean esVacia(){
        return primero() == null;
    }
    
}

