/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package librerias.estructurasDeDatos.modelos;

import librerias.estructurasDeDatos.lineales.NodoLEG;

/**Interfaz que aloja los metodos de la LECola
 *
 * @author Adrian Herrero Artola y Juan Blanco Martin
 * @param <E> Objeto de tipo generico
 */
public interface Cola<E> {
    /** Metodo recursivo que nos devuelve el numero de elementos que estan almacenados en la cola.
     * 
     * @param actual Es el nodo que evaluaremos en la invocacion del metodo en la que nos encontremos. Distinguimos casos en funcion de si se trata del ultimo nodo o no
     * @return 0 si el nodo actual es null, 1 + lo que resulte la llamada recursiva si el nodo actual no es null
     */
    abstract int contarElemCola(NodoLEG<E> actual);
    /** Metodo que permite insertar un nodo en el final de la lista (es decir, al final de la cola)
     * @param x (objeto generico)
     */
    abstract void encolar(E x);
    /** Metodo que permite eliminar el primer nodo de la lista (es decir, el nodo que se encuentra al frente de la cola)
     * @return frente Es el dato que ha desencolado
     */
    abstract E desencolar();
    /** Metodo que devuelve el objeto que se encuentra en el primer nodo de la lista (es decir, el que se encuentra al frente de la cola)
     * @return retorno Es el dato contenido en el primer nodo de la cola
     */
    abstract E primero();
    /** Metodo que devuelve un booleano indicando si la cola se encuentra vacia
     * @return Si el primer dato del primer nodo de la cola es null, lo cual indicaria que la cola esta vacia y devolveria true. En caso contrario, la cola no estaria vacia y devolveria por tanto false
     */
    abstract boolean esVacia();
}
