/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package librerias.tiposDeDatos;

/** Clase utilizada para la creacion de objetos de tipo Trabajo
 *
* @author Adrian Herrero Artola y Juan Blanco Martin
 */
public class Trabajo{
    private final int DESPLAZAMIENTO_ID_PRIORIDAD = 100;

    /**
     * Es el id del usuario propietario del trabajo
     */
    protected int ID_Usuario;

    /**
     * Es el titulo del trabajo
     */
    protected String titulo;

    /**
     * Es el peso del trabajo
     */
    protected long peso;
    
    /** Constructor al que se le pasa el id de usuario, el titulo del trabajo y el peso del mismo
     * @param ID_Usuario Es el id del usuario propietario del trabajo
     * @param titulo Es el titulo del trabajo
     * @param peso Es el peso del trabajo
     */
    public Trabajo(int ID_Usuario, String titulo, long peso){
        this.ID_Usuario = ID_Usuario;
        this.titulo = titulo;
        this.peso = peso;
    }
    
    /** Constructor al que se le pasa un objeto de tipo Trabajo
     * @param t Objeto de tipo Trabajo
     */
    public Trabajo(Trabajo t){
        this.ID_Usuario = t.ID_Usuario;
        this.titulo = t.titulo;
        this.peso = t.peso;
    }

    /** Metodo que indica el ID_Usuario del trabajo
     * @return ID_Usuario Es el ID_Usuario del trabajo
     */
    public int getID_Usuario() {
        return ID_Usuario;
    }

    /** Metodo que actualiza el ID_Usuario del trabajo
     * @param ID_Usuario Es el ID_Usuario del trabajo
     */
    public void setID_Usuario(int ID_Usuario) {
        this.ID_Usuario = ID_Usuario;
    }

    /** Metodo que indica el titulo del trabajo
     * @return titulo Es el titulo del trabajo
     */
    public String getTitulo() {
        return titulo;
    }

    /** Metodo que actualiza el titulo del trabajo
     * @param titulo Es el titulo del trabajo
     */
    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    /** Metodo que indica el peso (tamano) del trabajo
     * @return peso Es el  peso (tamano) del trabajo
     */
    public long getPeso() {
        return peso;
    }

    /** Metodo que actualiza el peso (tamano) del trabajo
     * @param peso Es el peso (tamano) del trabajo
     */
    public void setPeso(long peso) {
        this.peso = peso;
    }
    
    /** Metodo que calcula la prioridad de un trabajo en funcion del ID_Usuario que tenga
     * @return la prioridad del trabajo (entero entre 1 y 9, ambos inclusive)
     */
    public int obtenerPrioridad(){        
        return ID_Usuario/DESPLAZAMIENTO_ID_PRIORIDAD;
    }
}

