/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package librerias.utilidades;

import librerias.utilidades.MyInput;

/** Clase que aloja los metodos usados para validar formatos en la entrada de datos por teclado por parte del usuario
 *
* @author Adrian Herrero Artola y Juan Blanco Martin
 */
public class Formatos {
	
    /** Constructor de la clase que no recibe ni actualiza ningun parametro, sino que llama al constructor de la superclase
     * 
     */
    public Formatos(){
        super();
    }
    
    /** Metodo que comprueba que el formato de opcion es correcto
     * @return opcion Entero con formato de entero
     */
    public static int opcionConFormatoCorrecto(){
        int opcion = -1;
        try {
            opcion = MyInput.readInt();
            System.out.println();
        }
        catch (NumberFormatException nfe) { System.out.println("\nEl formato del numero es erroneo"); }

        return opcion;
    }
    
    /** Metodo que comprueba si el id de usuario introducido es un entero comprendido en el intervalo [100-999]
     * @return id Es un entero comprendido en el intervalo [100-999]
     */
    public static int idConFormatoCorrecto(){
        int id = -1;
        try {
            id = MyInput.readInt();
            System.out.println();
            if(id < 100){ System.out.println("Error: no puede haber id de usuarios menores a 100\n"); }
            if(999 < id){ System.out.println("Error: no puede haber id de usuarios mayores a 999\n"); }
        }
        catch (NumberFormatException nfe) { System.out.println("\nEl formato del numero es erroneo"); }

        return id;
    }
    
    /** Metodo que comprueba si el peso introducido es un elemento tipo long mayor que 0
     * @return peso Es un tipo long mayor que 0
     */
    public static long pesoConFormatoCorrecto(){
        long peso = 0;
        try {
            peso = MyInput.readLong();
            System.out.println();
            if(peso < 0){ System.out.println("Error: no puede existir un peso negativo\n"); }
            if(peso == 0){ System.out.println("Error: no puede existir un peso con tamano 0\n"); }
        }
        catch (NumberFormatException nfe) { System.out.println("\nEl formato del numero es erroneo"); }

        return peso;
    }
    
    /** Metodo que comprueba si se responde a una pregunta con S/N
     * @return continuar true si se responde con 'S' (o 's') o false si se responde con 'N' (o 'n')
     */
    public static boolean continuarProcedimiento(){
        String respuesta;
        boolean continuar = false;
        boolean respuestaValida;
    
        do{
            respuesta = MyInput.readString();

            if((respuesta.equalsIgnoreCase("n")) || (respuesta.equalsIgnoreCase("N"))){
                respuestaValida = true;
                System.out.println();
            }

            else if((!respuesta.equalsIgnoreCase("s")) && (!respuesta.equalsIgnoreCase("S"))){
                System.out.print("Respuesta no valida. Introduce 'S' o 'N': ");
                respuestaValida = false;
            }

            else{
                continuar = true;
                respuestaValida = true;
            }

        }while(!respuestaValida);

        return continuar;
    }
    
    /** Metodo que comprueba si la prioridad introducida es un entero comprendido en el intervalo [1-9]
     * @return prioridad Es un entero comprendido en el intervalo [1-9]
     */
    public static int prioridadConFormatoCorrecto(){
        int prioridad = -1;
        try {
            prioridad = MyInput.readInt();
            System.out.println();
            if(prioridad < 1){ System.out.println("Error: no existen prioridades menores de 1\n"); }
            else if(9 < prioridad){ System.out.println("Error: no existen prioridades mayores de 9\n"); }
        }
        catch (NumberFormatException nfe) { System.out.println("\nEl formato del numero es erroneo"); }

        return prioridad;
    }
}
