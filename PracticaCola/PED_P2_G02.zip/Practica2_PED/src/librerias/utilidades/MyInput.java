/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package librerias.utilidades;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


/** La clase MyInput permite la entrada de datos en el programa 
* 
* @author Adrian Herrero Artola y Juan Blanco Martin
*/
public class MyInput {

    /**
     * Lee un dato de tipo string desde el teclado
     * @return string
     */
    public static String readString() {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in),1);
        String string="";
        try {
        string = br.readLine(); }
        catch (IOException ex) {
        System.out.println(ex); }
        return string; }
    
    /**
     * Lee un dato tipo int desde el teclado
     * @return
     * @throws NumberFormatException
     */
    public static int readInt()throws NumberFormatException{ 
        return Integer.parseInt(readString()); }

    /**
     * Lee un dato tipo double desde el teclado
     * @return
     */
    public static double readDouble() {
        return Double.parseDouble(readString()); }

    /**
     * Lee un dato tipo byte desde el teclado
     * @return byte
     */
    public static byte readByte() {
        return Byte.parseByte(readString()); }

    /**
     * Lee un dato tipo short desde el teclado
     * @return short
     */
    public static short readShort() {
        return Short.parseShort(readString()); }

    /**
     * Lee un dato tipo long desde el teclado
     * @return
     */
    public static long readLong() {
        return Long.parseLong(readString()); }

    /**
     * Lee un dato tipo float desde el teclado
     * @return
     */
    public static float readFloat() {
        return Float.parseFloat(readString()); }
    
    /**
     * Permite la lectura de ficheros
     * @param nombreFichero
     */
    public static void leeFichero(String nombreFichero){
        File fichero=null;
        FileReader fr=null;
        BufferedReader br=null;
            
        try{
            fichero=new File(nombreFichero);
            fr = new FileReader(fichero);
            br = new BufferedReader(fr);
                
            String linea;
               
            while ((linea = br.readLine())!= null){
                System.out.println(linea);
            }
        }
        catch (Exception e){ e.printStackTrace(); }
        
        finally {
            try {
                if (null != fr){
                    fr.close();
                    br.close();
                }
            }
            catch (Exception e1){ e1.printStackTrace(); }
        }
    }
    
    /**
     * Permite la escritura de ficheros
     * @param nombreFichero
     * @param cadena
     */
    public static void escribeFichero(String nombreFichero, String cadena){            
        BufferedWriter bw = null;
        FileWriter fw = null;
        
        try{
            File file = new File(nombreFichero);
            
            //Si el archivo no existe, se crea
            if(!file.exists()){
                file.createNewFile();
            }
            
            //flag true, indica adjuntar informacion al archivo
            fw = new FileWriter(file.getAbsoluteFile(), true);
            bw = new BufferedWriter(fw);
            bw.write("\n"+cadena);
            System.out.println("Elemento agregado al archivo " + nombreFichero);
        }
        catch (IOException e){ e.printStackTrace(); }
        finally{
            try{
                //Cierra las instancias de FileWriter y BufferedWriter
                if(bw != null){
                    bw.close();
                }
                if(fw != null){
                    fw.close();
                }  
            }
            catch (IOException ex){ ex.printStackTrace(); }            
        }
    }
}

