/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package librerias.utilidades;

import librerias.utilidades.MyInput;


/** Clase responsable de la visualizacion del menu principal 
 *  y metodos utilizados en la interaccion con el menu
 *
* @author Adrian Herrero Artola y Juan Blanco Martin
 */
public class Menus {
    
    /** Constructor de la clase que no recibe ni actualiza ningun parametro, sino que llama al constructor de la superclase
     * 
     */
    public Menus(){
        super();
    }
    
    /** Metodo con la visualizacion del menu principal
     * @param opc -1 por defecto
     * @return El entero con la opcion elegida por el usuario
     */
    public static int menuPrincipal(int opc) {		
        System.out.println("      MENU PRINCIPAL");
        System.out.println("1.- Enviar un trabajo a la impresora");
        System.out.println("2.- Imprimir trabajos");
        System.out.println("3.- Mostrar trabajo mas pesado");
        System.out.println("4.- Mostrar tiempo de espera de un usuario");
        System.out.println("5.- Informe de trabajos por prioridad");
        System.out.println("6.- Informe de trabajos de una prioridad");
        System.out.println("7.- Reducir espera en una prioridad");
        System.out.println("8.- Reiniciar el Sistema de impresion");
        System.out.println("0.- Salir");
        System.out.print("Elija opcion: ");
            
        opc = Formatos.opcionConFormatoCorrecto();
	
        return opc;
    }
    
    /** Metodo para introducir correctamente el id de Usuario, segun los requisitos pedidos en el enunciado (que sea un entero entre [100-999])
     * @return id Es el ID_Usuario
     */
    public static int introducirIdUsuario(){
        int id = -1;
        while((id < 100) || (999 < id)){
            System.out.print("  Introduce el ID de Usuario: ");        
            id = Formatos.idConFormatoCorrecto();            
        }

        return id;
    } 
    
    /** Metodo para introducir titulo del trabajo
     * @return MyInput.readString() Es la cadena que representa el titulo del trabajo
     */
    public static String introducirTituloTrabajo(){
        System.out.print("  Introduce el titulo del trabajo a imprimir: ");        
        return MyInput.readString();
    } 
    
    /** Metodo para introducir peso del trabajo
     * @return peso Es una variable tipo long que representa el peso (tamano) del trabajo
     */
    public static long introducirPesoTrabajo(){
        long peso = -1;
        
        while(peso <= 0){
            System.out.print("  Introduce el peso del trabajo a imprimir (en Kb): ");        
            peso = Formatos.pesoConFormatoCorrecto();
        }

        return peso;
    }
    
    /** Metodo para introducir una prioridad, segun los requisitos pedidos en el enunciado (que sea un entero entre [1-9])
     * @return prioridad Es un entero en el intervalo [1-9]
     */
    public static int introducirPrioridad(){
        int prioridad = -1;
        while((prioridad < 1) || (9 < prioridad)){
            System.out.print("  Introduce una prioridad: ");        
            prioridad = Formatos.prioridadConFormatoCorrecto();            
        }

        return prioridad;
    }
}
